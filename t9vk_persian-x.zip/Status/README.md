# Welcome to Advanced Status!

### 1: In config.json put your token then put the type you want (types below) then put the text you want in status
### 2: Make sure you have node and git
### 3: Open git in the folder and type "node main.js"

# TYPES:

### WATCHING
### PLAYING
### LISTENING

# Setup
- The discord bot requires [Node.js](https://nodejs.org/) v8+ to run.
- Download the discord bot by going to the top right of the screen and press the "clone or download" button and press "Download ZIP"
- Once extracted into a folder run npm install in console to install all of the required packages
- Add the bots discord token and bots ID into the settings file found in "SettingsConfig"
- Once that is done run the bot by typing node index into console

## Credits

- Ben Wall - Main developer
- Alen Kalac - Code tester
- James Broadberry - Code tester


